//
//  ChartTableViewCell.swift
//  GraphPlot
//
//  Created by Sanskar IOS Dev on 23/12/24.
//

import UIKit
import Charts

class ChartTableViewCell: UITableViewCell {
    // Title label for the row
    let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        label.textAlignment = .left
        return label
    }()

    // A horizontal stack view to hold the pie charts
    let chartStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 8
        return stackView
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        // Add title label and chart stack view to contentView
        contentView.addSubview(titleLabel)
        contentView.addSubview(chartStackView)
        
        // Layout
        NSLayoutConstraint.activate([
            // Title label layout
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            
            // Chart stack view layout
            chartStackView.leadingAnchor.constraint(equalTo: titleLabel.trailingAnchor, constant: 16),
            chartStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            chartStackView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            chartStackView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // Configure the cell with data
    func configure(title: String, dataSets: [[Int]], labels: [[String]]) {
        titleLabel.text = title
        
        // Clear any old charts
        chartStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        // Iterate through the datasets
        for (index, data) in dataSets.enumerated() {
            guard index < labels.count else {
                print("Warning: Mismatched data and label sizes")
                continue
            }
            
            let pieChartView = PieChartView()
            pieChartView.translatesAutoresizingMaskIntoConstraints = false
            pieChartView.holeRadiusPercent = 0.5 // Customize as needed
            pieChartView.legend.enabled = false
            
            // Convert Int to Double for PieChartDataEntry
            var entries: [PieChartDataEntry] = []
            for (i, value) in data.enumerated() {
                if i < labels[index].count {
                    entries.append(PieChartDataEntry(value: Double(value), label: labels[index][i]))
                } else {
                    print("Warning: Mismatched data and label counts for dataset \(index)")
                }
            }
            
            let dataSet = PieChartDataSet(entries: entries, label: "")
            dataSet.colors = ChartColorTemplates.colorful()
            dataSet.valueTextColor = UIColor.clear // Hide value text
            dataSet.valueFont = UIFont.systemFont(ofSize: 12)
            
            pieChartView.data = PieChartData(dataSet: dataSet)
            
            // Add pie chart to stack view
            chartStackView.addArrangedSubview(pieChartView)
            
            // Set pie chart constraints
            NSLayoutConstraint.activate([
                pieChartView.heightAnchor.constraint(equalToConstant: 200),
                pieChartView.widthAnchor.constraint(equalToConstant: 200)
            ])
        }
    }
}
