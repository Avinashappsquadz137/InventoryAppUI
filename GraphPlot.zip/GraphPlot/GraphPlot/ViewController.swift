//
//  ViewController.swift
//  GraphPlot
//
//  Created by Sanskar IOS Dev on 23/12/24.
//

import UIKit
import Charts

class ChartTableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let tableView = UITableView()
    
    // Dataset
    let data = [
        ("Oct", [[11, 2, 3]],[["PL", "Tour", "WFH", "Bal","Home"]]),
        ("Nov", [[1, 5, 3, 4]], [["PL", "Tour", "WFH", "Bal","Home"]]),
        ("Dec", [[1]], [["PL", "Tour", "WFH", "Bal","Home"]]),
        ("Jan", [[1, 12, 3, 51, 8]],[["PL", "Tour", "WFH", "Bal","Home"]]),
        ("Feb", [[1, 12, 3, 21, 8]], [["PL", "Tour", "WFH", "Bal","Home"]])
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Pie Chart Table"
        view.backgroundColor = .white
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(ChartTableViewCell.self, forCellReuseIdentifier: "ChartTableViewCell")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 120
        
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChartTableViewCell", for: indexPath) as! ChartTableViewCell
        let row = data[indexPath.row]
        cell.configure(title: row.0, dataSets: row.1, labels: row.2)
        return cell
    }
}
